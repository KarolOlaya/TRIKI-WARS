package jugabilidad;

import graficos.ganador;
import graficos.juego;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JPanel;

public class tablero extends JPanel {

    // declarar atributos
    private int ancho;
    private int altura;
    private int margen;
    private Color colorTablero;//tablero triqui amarillo
    private Color color_interno;// cuadritos negritos
    private clase_imagen jugadorActual;
    private clase_imagen turnoPartida;
    private Jugador jugador1;
    private Jugador jugador2;
    private Jugador jugador3;
    private ArrayList<recuadro> cuadros;// arreglo para guardar los cuadros tranparentes
    private dibujar_lineas cuadroFrontal1;
    private dibujar_lineas cuadroFrontal2;
    private dibujar_lineas cuadroFrontal3;
    private dibujar_lineas cuadroFrontal4;

    public tablero() {
        //cuadros chiquitos
        ancho = 80;
        altura = 80;
        color_interno = Color.BLUE;
        colorTablero = Color.RED;
        margen = 6;
        
        //crear jugadores
        jugador1 = new Jugador();
        jugador2 = new Jugador();
        jugador3 = new Jugador();
        
        cuadros = new ArrayList();//iniciamos la arraylist de los cuadros
        
        jugadorActual = clase_imagen.equis;// que jugador tiene el turno de juego
        turnoPartida = clase_imagen.equis;// que jugador empieza en esta partida
    }

    public void crear_tablero() {
        //tablero amarillo
        setLayout(null);// para q salga en el centro y no se pueda mover
        setSize(ancho * 6 + margen * 7, altura * 3 + margen * 4);
        setBackground(colorTablero);
        
        // los 4 cuadros frontales q dibujan las lineas
        cuadroFrontal1 = new dibujar_lineas(this.getWidth() / 2, this.getHeight());// parametros ancho y alto
        cuadroFrontal1.setLocation(0, 0);
        cuadroFrontal1.setOpaque(false);
        cuadroFrontal1.setEnabled(false);// para q no se pueda tocar
        add(cuadroFrontal1);// se añade al tablero
        
        cuadroFrontal2 = new dibujar_lineas(this.getWidth() / 2, this.getHeight());
        cuadroFrontal2.setLocation(106, 0);
        cuadroFrontal2.setOpaque(false);
        cuadroFrontal2.setEnabled(false);
        add(cuadroFrontal2);
        
        cuadroFrontal3 = new dibujar_lineas(this.getWidth() / 2, this.getHeight());
        cuadroFrontal3.setLocation(212, 0);
        cuadroFrontal3.setOpaque(false);
        cuadroFrontal3.setEnabled(false);
        add(cuadroFrontal3);
        
        cuadroFrontal4 = new dibujar_lineas(this.getWidth() / 2, this.getHeight());
        cuadroFrontal4.setLocation(317, 0);
        cuadroFrontal4.setOpaque(false);
        cuadroFrontal4.setEnabled(false);
        add(cuadroFrontal4);
        
        // se llama al metodo que crea los cuadros chiquitos
        crear_cuadros_internos();
    }

    // creacion cuadros chiquitos
    private void crear_cuadros_internos() {
        //espacio para empezar a dibujar dentro del tablero amarillo
        int x = margen;
        int y = margen;
        
        for (int n = 0; n < 3; n++) {
            x = margen;// cada q completa una fila deja un espacio de 6 pixeles hacia abajo
            for (int i = 0; i < 6; i++) {
                
                //invisibles
                recuadro cuadro = new recuadro(ancho, altura);
                cuadro.setCursor(new Cursor(Cursor.HAND_CURSOR));//para q aparesca la mano al pasar por encima cuadritos
                cuadro.setLocation(x, y);
                cuadro.setN(n);
                cuadro.setI(i);
                cuadro.setOpaque(false);
                add(cuadro);// se añaden primero al tablero amarillo y luego al arreglo
                cuadros.add(cuadro);//guarda los cuadros tranparentes
                crear_eventos_cuadro(cuadro);
                
                //negritos
                fondo_recuadro fondo = new fondo_recuadro(ancho, altura, color_interno);     
                fondo.setLocation(x, y);
                fondo.setOpaque(false);
                add(fondo);
                
                x += (ancho + margen);// cada que completa una columna deja un espacio de 6 pixeles hacia el lado
            }
            y += (altura + margen);// cada que completa una fila deja un espcaio hacia abajo
        }
    }

    public void crear_eventos_cuadro(recuadro cuadro) {
        MouseListener evento = new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            //al presionar con el mouse dibuja la imagen, mira la posicion y verifica con el metodo tres_en_raya si hay un ganador y dibuja la linea
            public void mousePressed(MouseEvent e) {
                if (cuadro.getDibujado())
                    return;
                
                clase_imagen Resultado = null;
                
                if (jugadorActual == clase_imagen.equis) {
                    cuadro.setDibuja_imagen(clase_imagen.equis);
                    jugador1.getTablero()[cuadro.getN()][cuadro.getI()] = 1;
                    Resultado = jugador1.tres_en_raya(jugador2, jugador3);//verifica si gano
                    resultado(Resultado, clase_imagen.equis);
                    jugadorActual = clase_imagen.triangulo;
                    cambiar_estilo(clase_imagen.triangulo);//cambia el icono del jugador de turno
                    
                } else if (jugadorActual == clase_imagen.triangulo) {
                    cuadro.setDibuja_imagen(clase_imagen.triangulo);
                    jugador2.getTablero()[cuadro.getN()][cuadro.getI()] = 1;
                    Resultado = jugador2.tres_en_raya(jugador1, jugador3);
                    resultado(Resultado, clase_imagen.triangulo);
                    jugadorActual = clase_imagen.circulo;
                    cambiar_estilo(clase_imagen.circulo);
                    
                } else if (jugadorActual == clase_imagen.circulo) {
                    cuadro.setDibuja_imagen(clase_imagen.circulo);
                    jugador3.getTablero()[cuadro.getN()][cuadro.getI()] = 1;
                    Resultado = jugador3.tres_en_raya(jugador1, jugador2);
                    resultado(Resultado, clase_imagen.circulo);
                    jugadorActual = clase_imagen.equis;
                    cambiar_estilo(clase_imagen.equis);
                }
                cuadro.setDibujado(true);
                repaint();//pinta los iconos
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        };
        cuadro.addMouseListener(evento);
    }

    //cambia la imagen x actual y o Δ en negro 
    public void cambiar_estilo(clase_imagen jugador_actual) {
        if (jugador_actual == clase_imagen.equis) {
            juego.jugador1_img.setRuta(ruta.equis);
            juego.name_jugador1.setForeground(new Color(101, 175, 245));
            juego.jugador2_img.setRuta(ruta.triangulo_no);
            juego.name_jugador2.setForeground(new Color(240, 240, 240, 100));
            juego.jugador3_img.setRuta(ruta.circulo_no);
            juego.name_jugador3.setForeground(new Color(240, 240, 240, 100));
            juego.jugador1_img.repaint();
            juego.jugador2_img.repaint();
            juego.jugador3_img.repaint();
            juego.name_jugador1.repaint();
            juego.name_jugador2.repaint();
            juego.name_jugador3.repaint();
        }
        if (jugador_actual == clase_imagen.triangulo) {
            juego.jugador2_img.setRuta(ruta.triangulo);
            juego.name_jugador2.setForeground(new Color(101, 175, 145));
            juego.jugador1_img.setRuta(ruta.equis_no);
            juego.name_jugador1.setForeground(new Color(240, 240, 240, 100));
            juego.jugador3_img.setRuta(ruta.circulo_no);
            juego.name_jugador3.setForeground(new Color(240, 240, 240, 100));
            juego.jugador1_img.repaint();
            juego.jugador2_img.repaint();
            juego.jugador3_img.repaint();
            juego.name_jugador1.repaint();
            juego.name_jugador2.repaint();
            juego.name_jugador3.repaint();
        }
        if (jugador_actual == clase_imagen.circulo) {
            juego.jugador3_img.setRuta(ruta.circulo);
            juego.name_jugador3.setForeground(new Color(202, 105, 220));
            juego.jugador1_img.setRuta(ruta.equis_no);
            juego.name_jugador1.setForeground(new Color(240, 240, 240, 100));
            juego.jugador2_img.setRuta(ruta.triangulo_no);
            juego.name_jugador2.setForeground(new Color(240, 240, 240, 100));
            juego.jugador1_img.repaint();
            juego.jugador2_img.repaint();
            juego.jugador3_img.repaint();
            juego.name_jugador1.repaint();
            juego.name_jugador2.repaint();
            juego.name_jugador3.repaint();
        }
    }

    public void resultado(clase_imagen resultado, clase_imagen jugadorGanador) {
        //muestra el mensaje de empate
        if (resultado == clase_imagen.empate) {
            System.out.println("Empate");
            ganador jugador_ganador = new ganador(clase_imagen.empate, this);
            jugador_ganador.setVisible(true);
        }
        
        //mostrar el mensaje de ganador y mira en que cuadro dibujar la linea
        if (resultado != clase_imagen.empate && resultado != null) {
            System.out.println("Hay un ganador");
            ruta.cambiarRutas(jugadorGanador);
            int zona = Jugador.getPosision();
            switch(zona) {
                case (1):
                    cuadroFrontal1.setDibuja_linea(resultado);
                    break;
                case (2):
                    cuadroFrontal2.setDibuja_linea(resultado);
                    break;
                case (3):
                    cuadroFrontal3.setDibuja_linea(resultado);
                    break;
                case (4):
                    cuadroFrontal4.setDibuja_linea(resultado);
                    break;
            }
            //como ya hay un ganador se desactivan los cuadros para que nadie pueda seguir jugando
            desactivarCuadros(true);
            tablero tablero = this;
            
            Timer tiempo_espera = new Timer();
            TimerTask tarea = new TimerTask() {
                @Override
                public void run() {
                    ganador jugador_ganador = new ganador(jugadorGanador, tablero);
                    jugador_ganador.setVisible(true);
                }
            };
            tiempo_espera.schedule(tarea, 1000);// linea y despues pantalla
        }
    }

    // a todos los cuadros les va a pasar setDibujado como si ya tuvieran una imagen
    public void desactivarCuadros(boolean valor) {
        for (recuadro cuadro : cuadros) {
            cuadro.setDibujado(valor);
        }
    }

    // al reiniciar el juego se borran las imagen paraa volvera poner otras
    public void borrarImagenes() {
        for (recuadro cuadro : cuadros) {
            cuadro.setDibuja_imagen(null);
        }
    }

    public void reiniciar_tablero() {
        desactivarCuadros(false);
        borrarImagenes();
        
        //borra las lineas para que se puedan volver a poner
        cuadroFrontal1.setDibuja_linea(null);
        cuadroFrontal2.setDibuja_linea(null);
        cuadroFrontal3.setDibuja_linea(null);
        cuadroFrontal4.setDibuja_linea(null);
        
        //turnos
        if (turnoPartida == clase_imagen.equis) {
            jugadorActual = clase_imagen.triangulo;
            turnoPartida = clase_imagen.triangulo;
        } else if (turnoPartida == clase_imagen.triangulo) {
            jugadorActual = clase_imagen.circulo;
            turnoPartida = clase_imagen.circulo;
        } else if (turnoPartida == clase_imagen.circulo) {
            jugadorActual = clase_imagen.equis;
            turnoPartida = clase_imagen.equis;
        }
        
        //para que se vea que jugador empieza blanco y negro
        cambiar_estilo(jugadorActual);
        jugador1.limpiar_tablero();
        jugador2.limpiar_tablero();
        jugador3.limpiar_tablero();
        repaint();
    }

    //tablero amarillo redondo
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g3 = (Graphics2D) g.create();
        RoundRectangle2D.Double redonda = new RoundRectangle2D.Double(0, 0, this.getWidth() - 1, this.getHeight() - 1, 20, 20);
        g3.setColor(this.getBackground());
        g3.fill(redonda);
        g3.setColor(new Color(255, 255, 0));
        g3.draw(redonda);
        g3.dispose();
    }

    public int getAncho() {
        return ancho;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getMargen() {
        return margen;
    }

    public void setMargen(int margen) {
        this.margen = margen;
    }

    public void setColorTablero(Color colorTablero) {
        this.colorTablero = colorTablero;
    }

    public void setColor_interno(Color color_interno) {
        this.color_interno = color_interno;
    }

    public void setJugador1(Jugador jugador1) {
        this.jugador1 = jugador1;
    }

    public void setJugador2(Jugador jugador2) {
        this.jugador2 = jugador2;
    }

    public void setJugador3(Jugador jugador3) {
        this.jugador3 = jugador3;
    }

    public ArrayList<recuadro> getCuadros() {
        return cuadros;
    }

    public void setCuadros(ArrayList<recuadro> cuadros) {
        this.cuadros = cuadros;
    }

    public void reiniciar_tablero(clase_imagen ganador) {
    }


    public void setTurnoPartida(clase_imagen turnoPartida) {
    }

}

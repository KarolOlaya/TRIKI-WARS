package graficos;

import java.awt.Color;

public class creditos extends javax.swing.JFrame {

    public creditos() {
        setUndecorated(true);
        initComponents();
        setResizable(false);// como es falso no permite cambiar el tamaño de la ventana
        setLocationRelativeTo(null);// como es null(nulo) no se puede mover la ventana
        fondo.setOpaque(false);// se vuelve invisible el fondo
        parte_superior.setOpaque(false);// se vuelve invisible el fondo de la flecha
        setBackground(new Color(0, 0, 0, 0));
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        jLabel3 = new javax.swing.JLabel();
        imagen4 = new jugabilidad.imagen();
        fondo = new jugabilidad.redondeado();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        parte_superior = new jugabilidad.redondeado();
        imagen6 = new jugabilidad.imagen();
        jLabel6 = new javax.swing.JLabel();
        jLabel3.setFont(new java.awt.Font("Perpetua", 0, 24));
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Diseño: Karol Yulian Olaya y Julian Esteban Sanchez");
        jLabel3.setToolTipText("");
        jLabel3.setAlignmentY(0.0F);
        imagen4.setText("imagen4");
        imagen4.setRuta("/recursos/flecha.png");
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        fondo.setBackground(new java.awt.Color(0, 0, 0));
        fondo.setLayout(null);
        jLabel1.setFont(new java.awt.Font("Footlight MT Light", 0, 24));
        jLabel1.setForeground(new java.awt.Color(255, 255, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Diseño: Karol Yulian Olaya y Julian Esteban Sanchez");
        jLabel1.setToolTipText("");
        jLabel1.setAlignmentY(0.0F);
        fondo.add(jLabel1);
        jLabel1.setBounds(0, 140, 700, 120);
        jLabel2.setFont(new java.awt.Font("Footlight MT Light", 0, 24));
        jLabel2.setForeground(new java.awt.Color(255, 255, 0));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Codigo: Karol Yulian Olaya y Julian Esteban Sanchez");
        jLabel2.setToolTipText("");
        jLabel2.setAlignmentY(0.0F);
        fondo.add(jLabel2);
        jLabel2.setBounds(0, 270, 700, 120);
        jLabel4.setFont(new java.awt.Font("Footlight MT Light", 0, 24));
        jLabel4.setForeground(new java.awt.Color(255, 255, 0));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Assets: Karol Yulian Olaya y Julian Esteban Sanchez");
        jLabel4.setToolTipText("");
        jLabel4.setAlignmentY(0.0F);
        fondo.add(jLabel4);
        jLabel4.setBounds(0, 420, 700, 120);
        parte_superior.setBackground(new java.awt.Color(0, 0, 0));
        imagen6.setText("imagen4");
        imagen6.setRuta("/recursos/flecha.png");
        jLabel6.setBackground(new java.awt.Color(0, 0, 0));
        jLabel6.setFont(new java.awt.Font("Footlight MT Light", 1, 18));
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("          ");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel6MousePressed(evt);
            }
        });
        javax.swing.GroupLayout parte_superiorLayout = new javax.swing.GroupLayout(parte_superior);
        parte_superior.setLayout(parte_superiorLayout);
        parte_superiorLayout.setHorizontalGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, parte_superiorLayout.createSequentialGroup().addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE).addGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE).addComponent(imagen6, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)).addContainerGap()));
        parte_superiorLayout.setVerticalGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(parte_superiorLayout.createSequentialGroup().addContainerGap().addGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE).addComponent(imagen6, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)).addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE).addGap(0, 94, Short.MAX_VALUE)).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, Short.MAX_VALUE).addComponent(parte_superior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(parte_superior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED).addComponent(fondo, javax.swing.GroupLayout.PREFERRED_SIZE, 700, javax.swing.GroupLayout.PREFERRED_SIZE)));
        pack();
    }

    //flecha, para devolverse al menu principal
    private void jLabel6MousePressed(java.awt.event.MouseEvent evt) {
        this.dispose();
        ventana principal = new ventana();
        principal.setVisible(true);
    }

    private javax.swing.JPanel fondo;

    private jugabilidad.imagen imagen4;

    private jugabilidad.imagen imagen6;

    private javax.swing.JLabel jLabel1;

    private javax.swing.JLabel jLabel2;

    private javax.swing.JLabel jLabel3;

    private javax.swing.JLabel jLabel4;

    private javax.swing.JLabel jLabel6; //flecha

    private javax.swing.JPanel parte_superior; //panel negro para la flecha

    }
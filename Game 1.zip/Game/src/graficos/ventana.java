package graficos;

//sirve para poner el color
import java.awt.Color;
//sirve para crear bordes en los botones
import javax.swing.BorderFactory;
//sirve para crear objetos para almacenar y llamar esos bordes
import javax.swing.border.Border;

//es clase hija de JFrame
public class ventana extends javax.swing.JFrame {

    // metodo constructor
    public ventana() {
        setUndecorated(true); // quitar decoracion
        initComponents();
        setResizable(false);// como es falso no permite cambiar el tamaño de la ventana
        setLocationRelativeTo(null);// como es null(nulo) no se puede mover la ventana
        fondo.requestFocus();// el foco estara en el fondo
        fondo.setOpaque(false); // se vuelve invisible el fondo
        setBackground(new Color(0, 0, 0, 0)); // cambia la opacidad del antepenultimo fondo para que sea invisible
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        fondo = new jugabilidad.redondeado();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        imagen1 = new jugabilidad.imagen();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(700, 700));
        setSize(new java.awt.Dimension(700, 700));
        fondo.setBackground(new java.awt.Color(0, 0, 0));
        fondo.setAlignmentX(0.0F);
        fondo.setAlignmentY(0.0F);
        fondo.setMinimumSize(new java.awt.Dimension(700, 700));
        fondo.setNextFocusableComponent(fondo);
        fondo.setPreferredSize(new java.awt.Dimension(700, 700));
        fondo.setLayout(null);
        jButton1.setBackground(new java.awt.Color(204, 204, 0));
        jButton1.setFont(new java.awt.Font("Footlight MT Light", 0, 18));
        jButton1.setText("Jugar");
        jButton1.setAlignmentY(0.0F);
        jButton1.setBorder(null);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton1MouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton1MouseExited(evt);
            }

            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton1MousePressed(evt);
            }
        });
        fondo.add(jButton1);
        jButton1.setBounds(230, 370, 230, 40);
        jButton2.setBackground(new java.awt.Color(204, 204, 0));
        jButton2.setFont(new java.awt.Font("Footlight MT Light", 0, 18));
        jButton2.setText("Creditos");
        jButton2.setAlignmentY(0.0F);
        jButton2.setBorder(null);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton2MouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton2MouseExited(evt);
            }

            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton2MousePressed(evt);
            }
        });
        fondo.add(jButton2);
        jButton2.setBounds(230, 470, 230, 40);
        jButton3.setBackground(new java.awt.Color(204, 204, 0));
        jButton3.setFont(new java.awt.Font("Footlight MT Light", 0, 18));
        jButton3.setText("Salir");
        jButton3.setAlignmentY(0.0F);
        jButton3.setBorder(null);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jButton3MouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                jButton3MouseExited(evt);
            }

            public void mousePressed(java.awt.event.MouseEvent evt) {
                jButton3MousePressed(evt);
            }
        });
        fondo.add(jButton3);
        jButton3.setBounds(230, 570, 230, 40);
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("            v.1.0");
        jLabel2.setAlignmentY(0.0F);
        fondo.add(jLabel2);
        jLabel2.setBounds(0, 650, 700, 20);
        imagen1.setText("imagen1");
        imagen1.setRuta("/recursos/image.png");
        fondo.add(imagen1);
        imagen1.setBounds(190, 50, 300, 250);
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(fondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(fondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE));
        pack();
    }

    // al poner el mause encima cambia el color y da un borde
    private void jButton1MouseEntered(java.awt.event.MouseEvent evt) {
        jButton1.setBackground(new java.awt.Color(255, 255, 102));
        Border borde = BorderFactory.createLineBorder(new Color(255, 153, 51), 2);
        jButton1.setBorder(borde);
    }
    
    // al sacar el mouse de encima regresa el boton a como era antes
    private void jButton1MouseExited(java.awt.event.MouseEvent evt) {
        jButton1.setBackground(new java.awt.Color(204, 204, 0));
        jButton1.setBorder(null);
    }

    private void jButton2MouseExited(java.awt.event.MouseEvent evt) {
        jButton2.setBackground(new java.awt.Color(204, 204, 0));
        jButton2.setBorder(null);
    }
    
    private void jButton2MouseEntered(java.awt.event.MouseEvent evt) {
        jButton2.setBackground(new java.awt.Color(255, 255, 102));
        Border borde = BorderFactory.createLineBorder(new Color(255, 153, 51), 2);
        jButton2.setBorder(borde);
    }

    private void jButton3MouseExited(java.awt.event.MouseEvent evt) {
        jButton3.setBackground(new java.awt.Color(204, 204, 0));
        jButton3.setBorder(null);
    }
    
    private void jButton3MouseEntered(java.awt.event.MouseEvent evt) {
        jButton3.setBackground(new java.awt.Color(255, 255, 102));
        Border borde = BorderFactory.createLineBorder(new Color(255, 153, 51), 2);
        jButton3.setBorder(borde);
    }
    //fin

    // funcion boton
    private void jButton1MousePressed(java.awt.event.MouseEvent evt) {
        this.dispose();// llamar metodo de jframe que cierra la ventana inicio
        jugadores players = new jugadores();
        players.setVisible(true);// Se crea un objeto de la clase jugadores y se llama al metodo setVisible para que el objeto se puede observar en pantalla
    }

    private void jButton2MousePressed(java.awt.event.MouseEvent evt) {
        this.dispose();
        creditos biografia = new creditos();
        biografia.setVisible(true);
    }

    private void jButton3MousePressed(java.awt.event.MouseEvent evt) {
        System.exit(0); // metodo del sistema para cerrar el programa
    }

    // se crean los atributos
    
    private javax.swing.JPanel fondo;

    private jugabilidad.imagen imagen1;// logo

    private javax.swing.JButton jButton1;

    private javax.swing.JButton jButton2;

    private javax.swing.JButton jButton3;

    private javax.swing.JLabel jLabel2;// el texto de la esquina inferior

    
    }


package graficos;

import java.awt.Color;
import javax.swing.JLabel;
import jugabilidad.Jugador;
import jugabilidad.clase_imagen;
import jugabilidad.imagen;
import jugabilidad.tablero;

public class juego extends javax.swing.JFrame {

    private Jugador jugador1;

    private Jugador jugador2;

    private Jugador jugador3;

    private tablero tablero;

    public static JLabel name_jugador1;

    public static JLabel name_jugador2;

    public static JLabel name_jugador3;

    public static imagen jugador1_img;

    public static imagen jugador2_img;

    public static imagen jugador3_img;

    public static JLabel puntaje1;

    public static JLabel puntaje2;

    public static JLabel puntaje3;

    public juego(Jugador jugador1, Jugador jugador2, Jugador jugador3) {
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.jugador3 = jugador3;
        setUndecorated(true);
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        panelFondo.requestFocus();
        
        //se guardan los nombres q hayan digitado los jugadores en la clase jugadores
        nombre1.setText(jugador1.getNombre());
        nombre2.setText(jugador2.getNombre());
        nombre3.setText(jugador3.getNombre());
        
        // se crea un objeto de la clase tablero y se le dan las caracteristicas
        tablero = new tablero();
        tablero.setJugador1(jugador1);
        tablero.setJugador2(jugador2);
        tablero.setJugador3(jugador3);
        
        tablero.setAltura(100);
        tablero.setAncho(100);
        tablero.setMargen(5);
        tablero.setColor_interno(new Color(0, 0, 0));//color cuadros pequeños
        tablero.setColorTablero(new Color(255, 255, 0));//color tablero
        tablero.setLocation(30, 300);
        tablero.crear_tablero(); // se dan las especificaciones y luego se crea el tablero
        tablero.setVisible(true);
        
        // se añade el tablero al fondo del juego
        panelFondo.add(tablero);
        
        panelFondo.setOpaque(false);// se vuelve invisible el fondo
        tablero.setOpaque(false);// // se vuelve invisible el fondo del tablero
        parte_superior.setOpaque(false);// se vuelve invisible el fondo de la X
        setBackground(new Color(0, 0, 0, 0));
        
        // para poder acceder a los atributos privados guardamos estos en atributos publicos y estaticos
        name_jugador1 = nombre1;
        name_jugador2 = nombre2;
        name_jugador3 = nombre3;
        
        jugador1_img = img1;
        jugador2_img = img2;
        jugador3_img = img3;
        
        puntaje1 = puntos1;
        puntaje2 = puntos2;
        puntaje3 = puntos3;
        
        //Se situa a la X como el primer turno
        tablero.cambiar_estilo(clase_imagen.equis);
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        panelFondo = new jugabilidad.redondeado();
        nombre1 = new javax.swing.JLabel();
        nombre2 = new javax.swing.JLabel();
        nombre3 = new javax.swing.JLabel();
        puntos1 = new javax.swing.JLabel();
        puntos2 = new javax.swing.JLabel();
        puntos3 = new javax.swing.JLabel();
        img1 = new jugabilidad.imagen();
        img2 = new jugabilidad.imagen();
        img3 = new jugabilidad.imagen();
        parte_superior = new jugabilidad.redondeado();
        cerrar = new javax.swing.JLabel();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        panelFondo.setBackground(new java.awt.Color(0, 0, 0));
        panelFondo.setToolTipText("");
        panelFondo.setAlignmentX(0.0F);
        panelFondo.setAlignmentY(0.0F);
        panelFondo.setPreferredSize(new java.awt.Dimension(700, 700));
        panelFondo.setLayout(null);
        nombre1.setFont(new java.awt.Font("Footlight MT Light", 1, 20));
        nombre1.setForeground(new java.awt.Color(101, 175, 245));
        nombre1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nombre1.setText("name");
        panelFondo.add(nombre1);
        nombre1.setBounds(0, 100, 290, 30);
        nombre2.setFont(new java.awt.Font("Footlight MT Light", 1, 20));
        nombre2.setForeground(new java.awt.Color(101, 175, 145));
        nombre2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nombre2.setText("name");
        panelFondo.add(nombre2);
        nombre2.setBounds(0, 180, 690, 30);
        nombre3.setFont(new java.awt.Font("Footlight MT Light", 1, 20));
        nombre3.setForeground(new java.awt.Color(202, 105, 220));
        nombre3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nombre3.setText("name");
        panelFondo.add(nombre3);
        nombre3.setBounds(390, 100, 310, 30);
        puntos1.setFont(new java.awt.Font("Footlight MT Light", 0, 18));
        puntos1.setForeground(new java.awt.Color(255, 255, 255));
        puntos1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        puntos1.setText("0");
        panelFondo.add(puntos1);
        puntos1.setBounds(120, 140, 50, 17);
        puntos2.setFont(new java.awt.Font("Footlight MT Light", 0, 18));
        puntos2.setForeground(new java.awt.Color(255, 255, 255));
        puntos2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        puntos2.setText("0");
        panelFondo.add(puntos2);
        puntos2.setBounds(320, 220, 50, 17);
        puntos3.setFont(new java.awt.Font("Footlight MT Light", 0, 18));
        puntos3.setForeground(new java.awt.Color(255, 255, 255));
        puntos3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        puntos3.setText("0");
        panelFondo.add(puntos3);
        puntos3.setBounds(520, 140, 50, 17);
        img1.setText("imagen1");
        img1.setRuta("/recursos/Equis.png");
        panelFondo.add(img1);
        img1.setBounds(90, 10, 110, 100);
        img2.setText("imagen1");
        img2.setRuta("/recursos/Triangulo.png");
        panelFondo.add(img2);
        img2.setBounds(290, 80, 110, 100);
        img3.setText("imagen1");
        img3.setRuta("/recursos/Circulo.png");
        panelFondo.add(img3);
        img3.setBounds(490, 10, 110, 100);
        parte_superior.setBackground(new java.awt.Color(0, 0, 0));
        parte_superior.setPreferredSize(new java.awt.Dimension(62, 62));
        cerrar.setFont(new java.awt.Font("Footlight MT Light", 1, 48));
        cerrar.setForeground(new java.awt.Color(153, 51, 0));
        cerrar.setText("X");
        cerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cerrar.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cerrarMouseClicked(evt);
            }

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cerrarMouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                cerrarMouseExited(evt);
            }
        });
        javax.swing.GroupLayout parte_superiorLayout = new javax.swing.GroupLayout(parte_superior);
        parte_superior.setLayout(parte_superiorLayout);
        parte_superiorLayout.setHorizontalGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, parte_superiorLayout.createSequentialGroup().addContainerGap(16, Short.MAX_VALUE).addComponent(cerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE).addContainerGap()));
        parte_superiorLayout.setVerticalGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, parte_superiorLayout.createSequentialGroup().addContainerGap(11, Short.MAX_VALUE).addComponent(cerrar).addContainerGap()));
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(panelFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE).addContainerGap(68, Short.MAX_VALUE)).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, Short.MAX_VALUE).addComponent(parte_superior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(parte_superior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE).addComponent(panelFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));
        pack();
    }

    // X
    private void cerrarMouseClicked(java.awt.event.MouseEvent evt) {
        System.exit(0);// cerrar programa
    }

    // cuando el mouse esta encima se pone clarito
    private void cerrarMouseEntered(java.awt.event.MouseEvent evt) {
        cerrar.setForeground(new Color(255, 51, 51));
    }

    // cuando el mause sale de encima de la X se pone oscurito
    private void cerrarMouseExited(java.awt.event.MouseEvent evt) {
        cerrar.setForeground(new Color(153, 51, 0));
    }

    public Jugador getJugador1() {
        return jugador1;
    }

    public Jugador getJugador2() {
        return jugador2;
    }

    public Jugador getJugador3() {
        return jugador3;
    }
    
    private javax.swing.JLabel cerrar;

    public jugabilidad.imagen img1;

    public jugabilidad.imagen img2;

    public jugabilidad.imagen img3;

    private javax.swing.JLabel nombre1;

    private javax.swing.JLabel nombre2;

    private javax.swing.JLabel nombre3;

    private javax.swing.JPanel panelFondo;

    private javax.swing.JPanel parte_superior;

    private javax.swing.JLabel puntos1;

    private javax.swing.JLabel puntos2;

    private javax.swing.JLabel puntos3;




}

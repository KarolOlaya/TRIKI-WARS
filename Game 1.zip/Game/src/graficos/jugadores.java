package graficos;

import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import jugabilidad.Jugador;
import jugabilidad.clase_imagen;

public class jugadores extends javax.swing.JFrame {

    static juego jueguito;// se crea un objeto estatico de la clase juego, al ser estatico se puede llamar sin crear un objeto de la clase jugadores en otras clases

    public jugadores() {
        setUndecorated(true);
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        panelFondo.requestFocus();// el foco estara en el fondo
        panelFondo.setOpaque(false);// se vuelve invisible el fondo
        parte_superior.setOpaque(false);// se vuelve invisible el fondo de la flecha
        setBackground(new Color(0, 0, 0, 0));
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        panelFondo = new jugabilidad.redondeado();
        nameJugador1 = new javax.swing.JTextField();
        nameJugador2 = new javax.swing.JTextField();
        nameJugador3 = new javax.swing.JTextField();
        boton = new javax.swing.JPanel();
        comenzar = new javax.swing.JLabel();
        imagen1 = new jugabilidad.imagen();
        imagen2 = new jugabilidad.imagen();
        imagen3 = new jugabilidad.imagen();
        parte_superior = new jugabilidad.redondeado();
        imagen4 = new jugabilidad.imagen();
        jLabel1 = new javax.swing.JLabel();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        panelFondo.setBackground(new java.awt.Color(0, 0, 0));
        panelFondo.setToolTipText("");
        panelFondo.setAlignmentX(0.0F);
        panelFondo.setAlignmentY(0.0F);
        panelFondo.setPreferredSize(new java.awt.Dimension(700, 700));
        panelFondo.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mousePressed(java.awt.event.MouseEvent evt) {
                panelFondoMousePressed(evt);
            }
        });
        panelFondo.setLayout(null);
        nameJugador1.setBackground(new java.awt.Color(214, 252, 249));
        nameJugador1.setFont(new java.awt.Font("Footlight MT Light", 1, 28));
        nameJugador1.setForeground(new java.awt.Color(101, 175, 245));
        nameJugador1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nameJugador1.setText("NOMBRE...");
        nameJugador1.setToolTipText("");
        nameJugador1.setBorder(null);
        nameJugador1.addFocusListener(new java.awt.event.FocusAdapter() {

            public void focusGained(java.awt.event.FocusEvent evt) {
                nameJugador1FocusGained(evt);
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                nameJugador1FocusLost(evt);
            }
        });
        nameJugador1.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nameJugador1MouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                nameJugador1MouseExited(evt);
            }
        });
        nameJugador1.addKeyListener(new java.awt.event.KeyAdapter() {

            public void keyTyped(java.awt.event.KeyEvent evt) {
                nameJugador1KeyTyped(evt);
            }
        });
        panelFondo.add(nameJugador1);
        nameJugador1.setBounds(280, 150, 230, 40);
        nameJugador2.setBackground(new java.awt.Color(208, 248, 239));
        nameJugador2.setFont(new java.awt.Font("Footlight MT Light", 1, 28));
        nameJugador2.setForeground(new java.awt.Color(101, 175, 145));
        nameJugador2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nameJugador2.setText("NOMBRE...");
        nameJugador2.setToolTipText("");
        nameJugador2.setBorder(null);
        nameJugador2.addFocusListener(new java.awt.event.FocusAdapter() {

            public void focusGained(java.awt.event.FocusEvent evt) {
                nameJugador2FocusGained(evt);
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                nameJugador2FocusLost(evt);
            }
        });
        nameJugador2.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nameJugador2MouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                nameJugador2MouseExited(evt);
            }
        });
        nameJugador2.addKeyListener(new java.awt.event.KeyAdapter() {

            public void keyTyped(java.awt.event.KeyEvent evt) {
                nameJugador2KeyTyped(evt);
            }
        });
        panelFondo.add(nameJugador2);
        nameJugador2.setBounds(280, 260, 230, 40);
        nameJugador3.setBackground(new java.awt.Color(249, 230, 254));
        nameJugador3.setFont(new java.awt.Font("Footlight MT Light", 1, 28));
        nameJugador3.setForeground(new java.awt.Color(202, 105, 220));
        nameJugador3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        nameJugador3.setText("NOMBRE...");
        nameJugador3.setToolTipText("");
        nameJugador3.setBorder(null);
        nameJugador3.addFocusListener(new java.awt.event.FocusAdapter() {

            public void focusGained(java.awt.event.FocusEvent evt) {
                nameJugador3FocusGained(evt);
            }

            public void focusLost(java.awt.event.FocusEvent evt) {
                nameJugador3FocusLost(evt);
            }
        });
        nameJugador3.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                nameJugador3MouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                nameJugador3MouseExited(evt);
            }
        });
        nameJugador3.addKeyListener(new java.awt.event.KeyAdapter() {

            public void keyTyped(java.awt.event.KeyEvent evt) {
                nameJugador3KeyTyped(evt);
            }
        });
        panelFondo.add(nameJugador3);
        nameJugador3.setBounds(280, 370, 230, 40);
        boton.setBackground(new java.awt.Color(0, 204, 102));
        comenzar.setFont(new java.awt.Font("Footlight MT Light", 1, 36));
        comenzar.setForeground(new java.awt.Color(60, 100, 50));
        comenzar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        comenzar.setText("COMENZAR");
        comenzar.setAlignmentY(0.0F);
        comenzar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        comenzar.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                comenzarMouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                comenzarMouseExited(evt);
            }

            public void mousePressed(java.awt.event.MouseEvent evt) {
                comenzarMousePressed(evt);
            }
        });
        javax.swing.GroupLayout botonLayout = new javax.swing.GroupLayout(boton);
        boton.setLayout(botonLayout);
        botonLayout.setHorizontalGroup(botonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, botonLayout.createSequentialGroup().addGap(0, 0, Short.MAX_VALUE).addComponent(comenzar, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)));
        botonLayout.setVerticalGroup(botonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, botonLayout.createSequentialGroup().addGap(0, 0, Short.MAX_VALUE).addComponent(comenzar, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)));
        panelFondo.add(boton);
        boton.setBounds(210, 500, 270, 60);
        imagen1.setText("imagen1");
        imagen1.setRuta("/recursos/Circulo.png");
        panelFondo.add(imagen1);
        imagen1.setBounds(160, 340, 110, 100);
        imagen2.setText("imagen1");
        imagen2.setRuta("/recursos/Equis.png");
        panelFondo.add(imagen2);
        imagen2.setBounds(160, 120, 110, 100);
        imagen3.setText("imagen1");
        imagen3.setRuta("/recursos/Triangulo.png");
        panelFondo.add(imagen3);
        imagen3.setBounds(160, 230, 110, 100);
        parte_superior.setBackground(new java.awt.Color(0, 0, 0));
        imagen4.setText("imagen4");
        imagen4.setRuta("/recursos/flecha.png");
        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setFont(new java.awt.Font("Footlight MT Light", 1, 18));
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("          ");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });
        javax.swing.GroupLayout parte_superiorLayout = new javax.swing.GroupLayout(parte_superior);
        parte_superior.setLayout(parte_superiorLayout);
        parte_superiorLayout.setHorizontalGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, parte_superiorLayout.createSequentialGroup().addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE).addGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE).addComponent(imagen4, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)).addContainerGap()));
        parte_superiorLayout.setVerticalGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(parte_superiorLayout.createSequentialGroup().addContainerGap().addGroup(parte_superiorLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE).addComponent(imagen4, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)).addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)));
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(panelFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE).addContainerGap(83, Short.MAX_VALUE)).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, Short.MAX_VALUE).addComponent(parte_superior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(parte_superior, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE).addComponent(panelFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));
        pack();
    }

    // al poner el mause encima da un borde
    private void nameJugador1MouseEntered(java.awt.event.MouseEvent evt) {
        Border borde = BorderFactory.createLineBorder(new Color(52, 136, 235), 2);
        nameJugador1.setBorder(borde);
    }

    // al sacar el mouse de encima regresa el boton a como era antes
    private void nameJugador1MouseExited(java.awt.event.MouseEvent evt) {
        nameJugador1.setBorder(null);
    }

    private void nameJugador2MouseEntered(java.awt.event.MouseEvent evt) {
        Border borde = BorderFactory.createLineBorder(new Color(52, 152, 123), 2);
        nameJugador2.setBorder(borde);
    }

    private void nameJugador2MouseExited(java.awt.event.MouseEvent evt) {
        nameJugador2.setBorder(null);
    }

    private void nameJugador3MouseEntered(java.awt.event.MouseEvent evt) {
        Border borde = BorderFactory.createLineBorder(new Color(153, 86, 203), 2);
        nameJugador3.setBorder(borde);
    }

    private void nameJugador3MouseExited(java.awt.event.MouseEvent evt) {
        nameJugador3.setBorder(null);
    }
// fin
    
    //funcion boton
    private void nameJugador1FocusGained(java.awt.event.FocusEvent evt) {
        if (nameJugador1.getText().equals("NOMBRE...")) { // usamos el equals pára compar si el texto de jugador1 es igual a NOMBRE...
            nameJugador1.setText("");// si es igual entonces se cambia el texto mediante setText a "" (es decir sin texto)
        }
    }

    private void nameJugador2FocusGained(java.awt.event.FocusEvent evt) {
        if (nameJugador2.getText().equals("NOMBRE...")) {
            nameJugador2.setText("");
        }
    }

    private void nameJugador3FocusGained(java.awt.event.FocusEvent evt) {
        if (nameJugador3.getText().equals("NOMBRE...")) {
            nameJugador3.setText("");
        }
    }

    private void nameJugador1FocusLost(java.awt.event.FocusEvent evt) {// si se pierde el foco y esta vacio sse devuelve NOMBRE...
        if (nameJugador1.getText().equals("")) {
            nameJugador1.setText("NOMBRE...");
        }
    }

    private void nameJugador2FocusLost(java.awt.event.FocusEvent evt) {
        if (nameJugador2.getText().equals("")) {
            nameJugador2.setText("NOMBRE...");
        }
    }

    private void nameJugador3FocusLost(java.awt.event.FocusEvent evt) {
        if (nameJugador3.getText().equals("")) {
            nameJugador3.setText("NOMBRE...");
        }
    }

    private void panelFondoMousePressed(java.awt.event.MouseEvent evt) {
        panelFondo.requestFocus();// cuando estemos en un boton y presionemos el fondo el foco pasa al fondo
    }

    //typed eventos de teclado
    private void nameJugador1KeyTyped(java.awt.event.KeyEvent evt) {
        char character = Character.toUpperCase(evt.getKeyChar());// detecta la tecla presionada y la convierte en mayuscula mediante el toUpperCase
        evt.setKeyChar(character);// guarda la tecla convertida en mayuscula
        if (nameJugador1.getText().length() >= 8) {
            evt.consume();//consume los caracteres cuando se es mayor a 8
        }
    }

    private void nameJugador2KeyTyped(java.awt.event.KeyEvent evt) {
        char character = Character.toUpperCase(evt.getKeyChar());
        evt.setKeyChar(character);
        if (nameJugador2.getText().length() >= 8) {
            evt.consume();
        }
    }

    private void nameJugador3KeyTyped(java.awt.event.KeyEvent evt) {
        char character = Character.toUpperCase(evt.getKeyChar());
        evt.setKeyChar(character);
        if (nameJugador3.getText().length() >= 8) {
            evt.consume();
        }
    }

    //flecha, para devolverse al menu principal
    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {
        this.dispose();
        ventana principal = new ventana();
        principal.setVisible(true);
    }
    
    //boton comenzar
    // al poner el mause encima cambia el color y da un borde
    private void comenzarMouseEntered(java.awt.event.MouseEvent evt) {
        Border borde = BorderFactory.createLineBorder(new Color(0, 153, 102), 4);
        comenzar.setBorder(borde);
        comenzar.setForeground(new Color(60, 102, 100));
        boton.setBackground(new Color(100, 232, 156));
    }
    
     // al sacar el mouse de encima regresa el boton a como era antes
    private void comenzarMouseExited(java.awt.event.MouseEvent evt) {
        comenzar.setBorder(null);
        comenzar.setForeground(new Color(60, 100, 50));
        boton.setBackground(new Color(0, 204, 102));
    }

    // al presionar si los nombres son igual a "" o NOMBRE... los cambia a Jugador azul, verde, rosa
    private void comenzarMousePressed(java.awt.event.MouseEvent evt) {
        
        Jugador jugador1 = new Jugador(clase_imagen.equis);
        if (nameJugador1.getText().equals("") || nameJugador1.getText().equals("NOMBRE...")) {
            jugador1.setNombre("Jugador azul");
        } else {
            jugador1.setNombre(nameJugador1.getText());
        }
        Jugador jugador2 = new Jugador(clase_imagen.circulo);
        if (nameJugador2.getText().equals("") || nameJugador2.getText().equals("NOMBRE...")) {
            jugador2.setNombre("Jugador verde");
        } else {
            jugador2.setNombre(nameJugador2.getText());
        }
        Jugador jugador3 = new Jugador(clase_imagen.triangulo);
        if (nameJugador3.getText().equals("") || nameJugador3.getText().equals("NOMBRE...")) {
            jugador3.setNombre("Jugador rosa");
        } else {
            jugador3.setNombre(nameJugador3.getText());
        }
        
        this.dispose();// cerrar ventana y muestra el juego
        jueguito = new juego(jugador1, jugador2, jugador3);
        jueguito.setVisible(true);
    }

    private javax.swing.JPanel boton;

    private javax.swing.JLabel comenzar;

    private jugabilidad.imagen imagen1;

    private jugabilidad.imagen imagen2;

    private jugabilidad.imagen imagen3;

    private jugabilidad.imagen imagen4;

    private javax.swing.JLabel jLabel1;

    private javax.swing.JTextField nameJugador1;// espacio en el q se puede escribir

    private javax.swing.JTextField nameJugador2;

    private javax.swing.JTextField nameJugador3;

    private javax.swing.JPanel panelFondo;

    private javax.swing.JPanel parte_superior;


}

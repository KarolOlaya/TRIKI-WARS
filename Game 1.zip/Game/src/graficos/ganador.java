package graficos;

import java.awt.Color;
import java.util.Timer;
import java.util.TimerTask;
import jugabilidad.clase_imagen;
import jugabilidad.ruta;
import jugabilidad.tablero;

public class ganador extends javax.swing.JFrame {

    //atributos
    // Inter.parseInt convierte un string en un int
    int p1 = Integer.parseInt(jugadores.jueguito.puntaje1.getText());

    int p2 = Integer.parseInt(jugadores.jueguito.puntaje2.getText());

    int p3 = Integer.parseInt(jugadores.jueguito.puntaje3.getText());

    private tablero tablero;

    private clase_imagen jugador_ganador;

    public ganador(clase_imagen ganador, tablero objeto_tablero) {
        setUndecorated(true);
        initComponents();
        setResizable(false);
        setLocationRelativeTo(null);
        panelFondo.requestFocus();
        panelFondo.setOpaque(false);
        cubo.setOpaque(false);
        setBackground(new Color(0, 0, 0, 0));
        
        // se guardan los parametros en los atributos creados anteriormente
        tablero = objeto_tablero;
        jugador_ganador = ganador;
        
        if (p1 + 1 > 2 || p2 + 1 > 2 || p3 + 1 > 2) {
            ganador_text.setText("GANADOR");
        }
        
        if (ganador == clase_imagen.equis) {
            this.ganador.setRuta(ruta.equis);// para q busque la imagen del jugador en la ruta
            name_ganador.setText(juego.name_jugador1.getText());// escribe el nombre del jugador
            name_ganador.setForeground(new Color(101, 175, 245));// le cambia el color al nombre del jugador segun quien gano
            this.sable.setRuta(ruta.LINEA8);// para q busque y dibuje el sable del jugador ganador
            int puntaje_nuevo = Integer.parseInt(juego.puntaje1.getText()) + 1;// para pasar el string de puntuacion a un entero y sumarle un punto
            juego.puntaje1.setText(String.valueOf(puntaje_nuevo));// pasa el puntaje de numero a texto para q se vea en pantalla
            
        } else if (ganador == clase_imagen.triangulo) {
            this.ganador.setRuta(ruta.triangulo);
            name_ganador.setText(juego.name_jugador2.getText());
            name_ganador.setForeground(new Color(101, 175, 145));
            this.sable.setRuta(ruta.LINEA8);
            int puntaje_nuevo = Integer.parseInt(juego.puntaje2.getText()) + 1;
            juego.puntaje2.setText(String.valueOf(puntaje_nuevo));
            
        } else if (ganador == clase_imagen.circulo) {
            this.ganador.setRuta(ruta.circulo);
            name_ganador.setText(juego.name_jugador3.getText());
            name_ganador.setForeground(new Color(202, 105, 220));
            this.sable.setRuta(ruta.LINEA8);
            int puntaje_nuevo = Integer.parseInt(juego.puntaje3.getText()) + 1;
            juego.puntaje3.setText(String.valueOf(puntaje_nuevo));
            
        } else if (ganador == clase_imagen.empate) {
            this.ganador.setRuta("");
            this.sable.setRuta("");
            name_ganador.setText("Sin puntos");
            name_ganador.setForeground(new Color(255,255,0));
            ganador_text.setText("EMPATE");
            ganador_text.setForeground(Color.RED);
        }
    }

    @SuppressWarnings("unchecked")
    private void initComponents() {
        panelFondo = new jugabilidad.redondeado();
        ganador = new jugabilidad.imagen();
        cerrar = new javax.swing.JLabel();
        sable = new jugabilidad.imagen();
        name_ganador = new javax.swing.JLabel();
        ganador_text = new javax.swing.JLabel();
        cubo = new javax.swing.JPanel();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        panelFondo.setBackground(new java.awt.Color(0, 0, 0));
        panelFondo.setToolTipText("");
        panelFondo.setAlignmentX(0.0F);
        panelFondo.setAlignmentY(0.0F);
        panelFondo.setPreferredSize(new java.awt.Dimension(700, 700));
        panelFondo.setLayout(null);
        ganador.setText("imagen1");
        ganador.setRuta("/recursos/Equis.png");
        panelFondo.add(ganador);
        ganador.setBounds(110, 140, 130, 110);
        cerrar.setFont(new java.awt.Font("Footlight MT Light", 1, 48));
        cerrar.setForeground(new java.awt.Color(153, 51, 0));
        cerrar.setText("X");
        cerrar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cerrar.addMouseListener(new java.awt.event.MouseAdapter() {

            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cerrarMouseClicked(evt);
            }

            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cerrarMouseEntered(evt);
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                cerrarMouseExited(evt);
            }
        });
        panelFondo.add(cerrar);
        cerrar.setBounds(640, 20, 40, 40);
        sable.setText("imagen1");
        sable.setRuta("/recursos/Equis.png");
        panelFondo.add(sable);
        sable.setBounds(460, 140, 130, 110);
        name_ganador.setFont(new java.awt.Font("Footlight MT Light", 0, 36));
        name_ganador.setForeground(new java.awt.Color(255, 255, 255));
        name_ganador.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        name_ganador.setText("Nombre");
        name_ganador.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        panelFondo.add(name_ganador);
        name_ganador.setBounds(0, 160, 700, 80);
        ganador_text.setFont(new java.awt.Font("Footlight MT Light", 1, 56));
        ganador_text.setForeground(new java.awt.Color(255, 255, 0));
        ganador_text.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ganador_text.setText("+1 punto");
        ganador_text.setAlignmentY(0.0F);
        ganador_text.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        panelFondo.add(ganador_text);
        ganador_text.setBounds(0, 60, 700, 90);
        javax.swing.GroupLayout cuboLayout = new javax.swing.GroupLayout(cubo);
        cubo.setLayout(cuboLayout);
        cuboLayout.setHorizontalGroup(cuboLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 37, Short.MAX_VALUE));
        cuboLayout.setVerticalGroup(cuboLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGap(0, 41, Short.MAX_VALUE));
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(panelFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE).addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE).addComponent(cubo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));
        layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(panelFondo, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE).addGroup(layout.createSequentialGroup().addGap(89, 89, 89).addComponent(cubo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)));
        pack();
    }

    //evento X roja de ganador
    private void cerrarMouseClicked(java.awt.event.MouseEvent evt) {
        this.dispose();// cerrar la ventana de ganador       
        tablero.reiniciar_tablero();//se borran las imagenes para volver a jugar
          
        if (p1 == 2 && jugador_ganador != clase_imagen.triangulo && jugador_ganador != clase_imagen.circulo) {
            jugadores.jueguito.dispose();//borra ventana juego
            
            ganador_text.setText("+1 punto");//cambia el texto de ganador a +1
            
            ventana inicio = new ventana(); // se crea el objeto para abrir la ventana de inicio
            
            Timer tiempo_espera = new Timer();
            TimerTask tarea = new TimerTask() {
                @Override
                public void run() {// todo que este dentro de run se ejecutara al llamar al objeto tarea
                    inicio.setVisible(true);
                } };
            tiempo_espera.schedule(tarea, 650);// schedule sirve para asignar un tiempo de espera a una tarea
        }
        
        if (p2 == 2 && jugador_ganador != clase_imagen.equis && jugador_ganador != clase_imagen.circulo) {
            jugadores.jueguito.dispose();           
            ganador_text.setText("+1 punto");            
            ventana inicio = new ventana();            
            Timer tiempo_espera = new Timer();
            TimerTask tarea = new TimerTask() {
                @Override
                public void run() {
                    inicio.setVisible(true);
                }
            };
            tiempo_espera.schedule(tarea, 650);
        }
        if (p3 == 2 && jugador_ganador != clase_imagen.equis && jugador_ganador != clase_imagen.equis) {
            jugadores.jueguito.dispose();            
            ganador_text.setText("+1 punto");           
            ventana inicio = new ventana();           
            Timer tiempo_espera = new Timer();
            TimerTask tarea = new TimerTask() {
                @Override
                public void run() {
                    inicio.setVisible(true);
                }
            };
            tiempo_espera.schedule(tarea, 650);
        }
    }

    private void cerrarMouseEntered(java.awt.event.MouseEvent evt) {
        cerrar.setForeground(new Color(255, 51, 51));
    }

    private void cerrarMouseExited(java.awt.event.MouseEvent evt) {
        cerrar.setForeground(new Color(153, 51, 0));
    }
    
    private javax.swing.JLabel cerrar;

    private javax.swing.JPanel cubo;

    private jugabilidad.imagen ganador;

    private javax.swing.JLabel ganador_text;

    private javax.swing.JLabel name_ganador;

    private javax.swing.JPanel panelFondo;

    private jugabilidad.imagen sable;
    
}

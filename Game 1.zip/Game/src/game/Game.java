package game;

import graficos.ventana;

public class Game {

    // Se crea un objeto de la clase ventana y se llama al metodo setVisible para que el objeto se puede observar en pantalla
    public static void main(String[] args) {
        ventana ventana_juego = new ventana();
        ventana_juego.setVisible(true);
    }
}

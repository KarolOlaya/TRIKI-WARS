package jugabilidad;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

//cuadro invisible de los recuadros negritos que dibuja el icono del jugador
public class recuadro extends JPanel {

    private int ancho;

    private int altura;

    private clase_imagen dibuja_imagen;// dice si es x o Δ

    private boolean dibujado;// dibujado define si un cuadro ya tiene una imagen

    private int n;//fila

    private int i;//columna

    public recuadro(int ancho, int altura) {
        this.ancho = ancho;
        this.altura = altura;
        dibujado = false;// apenas comience el juego los cuadros no tienen imagenes
        setSize(ancho, altura);
    }

    @Override
    protected void paintComponent(Graphics gg) {    
        Graphics2D g = (Graphics2D) gg;
        ImageIcon imagen = new ImageIcon();// crea una imagen segun la ruta que se le asigne
        
        if (dibuja_imagen == clase_imagen.circulo) {
            imagen = new ImageIcon(getClass().getResource(ruta.circulo));
            
        } else if (dibuja_imagen == clase_imagen.equis) {
            imagen = new ImageIcon(getClass().getResource(ruta.equis));
            
        } else if (dibuja_imagen == clase_imagen.triangulo) {
            imagen = new ImageIcon(getClass().getResource(ruta.triangulo));
        }
        // los if dan la ruta y el draw dibuja
        g.drawImage(imagen.getImage(), 0, 0, this.getWidth(), this.getHeight(), null);
        // esta en 00 porq se dibuja en el centro del cuadro
    }

    // setters cambian el valor de n, i, ancho y altura, dibuja_imagen, dibujado, y getters permiten obtener los valores de los mismos
    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getI() {
        return i;
    }

    public void setI(int i) {
        this.i = i;
    }

    public boolean getDibujado() {
        return dibujado;
    }

    public void setDibujado(boolean dibujado) {
        this.dibujado = dibujado;
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public void setDibuja_imagen(clase_imagen dibuja_imagen) {
        this.dibuja_imagen = dibuja_imagen;
    }

}
package jugabilidad;

public class ruta {

    public static final String equis = "/recursos/Equis.png";

    public static final String circulo = "/recursos/Circulo.png";

    public static final String triangulo = "/recursos/Triangulo.png";

    public static final String equis_no = "/recursos/Equis_no.png";

    public static final String circulo_no = "/recursos/Circulo_no.png";

    public static final String triangulo_no = "/recursos/Triangulo_no.png";

    public static String LINEA1;

    public static String LINEA2;

    public static String LINEA3;

    public static String LINEA4;

    public static String LINEA5;

    public static String LINEA6;

    public static String LINEA7;

    public static String LINEA8;

    
    public static void cambiarRutas(clase_imagen objetolinea) {
        
        // en el objetolinea se va a almacenar el jugador actual para que asi el porgrama sepa q lineas dibujar si el jugador llega a ganar
        if (objetolinea == clase_imagen.circulo) {
            LINEA1 = "/recursos/CirculoLinea1.png";
            LINEA2 = "/recursos/CirculoLinea2.png";
            LINEA3 = "/recursos/CirculoLinea3.png";
            LINEA4 = "/recursos/CirculoLinea4.png";
            LINEA5 = "/recursos/CirculoLinea5.png";
            LINEA6 = "/recursos/CirculoLinea6.png";
            LINEA7 = "/recursos/CirculoLinea7.png";
            LINEA8 = "/recursos/CirculoLinea8.png";
            
        } else if (objetolinea == clase_imagen.equis) {
            LINEA1 = "/recursos/EquisLinea1.png";
            LINEA2 = "/recursos/EquisLinea2.png";
            LINEA3 = "/recursos/EquisLinea3.png";
            LINEA4 = "/recursos/EquisLinea4.png";
            LINEA5 = "/recursos/EquisLinea5.png";
            LINEA6 = "/recursos/EquisLinea6.png";
            LINEA7 = "/recursos/EquisLinea7.png";
            LINEA8 = "/recursos/EquisLinea8.png";
            
        } else if (objetolinea == clase_imagen.triangulo) {
            LINEA1 = "/recursos/TrianguloLinea1.png";
            LINEA2 = "/recursos/TrianguloLinea2.png";
            LINEA3 = "/recursos/TrianguloLinea3.png";
            LINEA4 = "/recursos/TrianguloLinea4.png";
            LINEA5 = "/recursos/TrianguloLinea5.png";
            LINEA6 = "/recursos/TrianguloLinea6.png";
            LINEA7 = "/recursos/TrianguloLinea7.png";
            LINEA8 = "/recursos/TrianguloLinea8.png";
        }
    }
}

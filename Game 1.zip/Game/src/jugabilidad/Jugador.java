package jugabilidad;

public class Jugador {

    private String nombre;

    private clase_imagen tipo_imagen;// dice si es x o Δ

    private int tablero[][];// arreglo para guardar posicion cuadros

    private static int posision;// nos indica si es el cuadro 1, 2 , 3 o 4 que dibuja las lineas

    
    public Jugador() {
        tablero = new int[3][6];// se inicia el arreglo con las filas y columnas
        limpiar_tablero();
    }

    public Jugador(clase_imagen tipo_imagen) {// pide si es x o Δ
        this.tipo_imagen = tipo_imagen;
        tablero = new int[3][6];// se inicia el arreglo con las filas y columnas
        limpiar_tablero();
    }

    public void limpiar_tablero() {
        for (int n = 0; n < 3; n++) {
            for (int i = 0; i < 6; i++) {
                tablero[n][i] = 0;
            }
        }
    }

    //se verifica si hay triqui y se retorna la linea correspondiente
    public clase_imagen tres_en_raya(Jugador jugadorRival1, Jugador jugadorRival2) {
        
        //posibles probabilidades
        if (tablero[0][0] == 1 && tablero[0][1] == 1 && tablero[0][2] == 1) {
            posision = 1;
            return clase_imagen.linea1;
        }
        if (tablero[0][3] == 1 && tablero[0][4] == 1 && tablero[0][5] == 1) {
            posision = 4;
            return clase_imagen.linea1;
        }
        if (tablero[0][1] == 1 && tablero[0][2] == 1 && tablero[0][3] == 1) {
            posision = 2;
            return clase_imagen.linea1;
        }
        if (tablero[0][2] == 1 && tablero[0][3] == 1 && tablero[0][4] == 1) {
            posision = 3;
            return clase_imagen.linea1;
        }
        if (tablero[1][0] == 1 && tablero[1][1] == 1 && tablero[1][2] == 1) {
            posision = 1;
            return clase_imagen.linea2;
        }
        if (tablero[1][3] == 1 && tablero[1][4] == 1 && tablero[1][5] == 1) {
            posision = 4;
            return clase_imagen.linea2;
        }
        if (tablero[1][1] == 1 && tablero[1][2] == 1 && tablero[1][3] == 1) {
            posision = 2;
            return clase_imagen.linea2;
        }
        if (tablero[1][2] == 1 && tablero[1][3] == 1 && tablero[1][4] == 1) {
            posision = 3;
            return clase_imagen.linea2;
        }
        if (tablero[2][0] == 1 && tablero[2][1] == 1 && tablero[2][2] == 1) {
            posision = 1;
            return clase_imagen.linea3;
        }
        if (tablero[2][3] == 1 && tablero[2][4] == 1 && tablero[2][5] == 1) {
            posision = 4;
            return clase_imagen.linea3;
        }
        if (tablero[2][1] == 1 && tablero[2][2] == 1 && tablero[2][3] == 1) {
            posision = 2;
            return clase_imagen.linea3;
        }
        if (tablero[2][2] == 1 && tablero[2][3] == 1 && tablero[2][4] == 1) {
            posision = 3;
            return clase_imagen.linea3;
        }
        if (tablero[0][0] == 1 && tablero[1][0] == 1 && tablero[2][0] == 1) {
            posision = 1;
            return clase_imagen.linea4;
        }
        if (tablero[0][1] == 1 && tablero[1][1] == 1 && tablero[2][1] == 1) {
            posision = 1;
            return clase_imagen.linea5;
        }
        if (tablero[0][2] == 1 && tablero[1][2] == 1 && tablero[2][2] == 1) {
            posision = 1;
            return clase_imagen.linea6;
        }
        if (tablero[0][3] == 1 && tablero[1][3] == 1 && tablero[2][3] == 1) {
            posision = 4;
            return clase_imagen.linea4;
        }
        if (tablero[0][4] == 1 && tablero[1][4] == 1 && tablero[2][4] == 1) {
            posision = 4;
            return clase_imagen.linea5;
        }
        if (tablero[0][5] == 1 && tablero[1][5] == 1 && tablero[2][5] == 1) {
            posision = 4;
            return clase_imagen.linea6;
        }
        if (tablero[2][0] == 1 && tablero[1][1] == 1 && tablero[0][2] == 1) {
            posision = 1;
            return clase_imagen.linea7;
        }
        if (tablero[2][2] == 1 && tablero[1][1] == 1 && tablero[0][0] == 1) {
            posision = 1;
            return clase_imagen.linea8;
        }
        if (tablero[2][1] == 1 && tablero[1][2] == 1 && tablero[0][3] == 1) {
            posision = 2;
            return clase_imagen.linea7;
        }
        if (tablero[2][3] == 1 && tablero[1][2] == 1 && tablero[0][1] == 1) {
            posision = 2;
            return clase_imagen.linea8;
        }
        if (tablero[2][2] == 1 && tablero[1][3] == 1 && tablero[0][4] == 1) {
            posision = 3;
            return clase_imagen.linea7;
        }
        if (tablero[2][4] == 1 && tablero[1][3] == 1 && tablero[0][2] == 1) {
            posision = 3;
            return clase_imagen.linea8;
        }
        if (tablero[2][3] == 1 && tablero[1][4] == 1 && tablero[0][5] == 1) {
            posision = 4;
            return clase_imagen.linea7;
        }
        if (tablero[2][5] == 1 && tablero[1][4] == 1 && tablero[0][3] == 1) {
            posision = 4;
            return clase_imagen.linea8;
        }
        
        //empate
        int contador = 0;
        for (int n = 0; n < 3; n++) {//filas
            for (int i = 0; i < 6; i++) {//columnas
                if (tablero[n][i] == 1) {
                    contador++;// si ya hay una imagen en esa posicion se suma 1 a contador
                }
                if (jugadorRival1.getTablero()[n][i] == 1) {
                    contador++;// si el rival ya tiene una imagen en esa posicion se suma 1 a contador
                }
                if (jugadorRival2.getTablero()[n][i] == 1) {
                    contador++;// si el rival ya tiene una imagen en esa posicion se suma 1 a contador
                }
            }
        }
        if (contador == 18) {
            return clase_imagen.empate;
        }
        return null;
    }

    // setters cambian el valor de los atributos, y getters permiten obtener los valores de los mismos
    public int[][] getTablero() {
        return tablero;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public clase_imagen getTipo_imagen() {
        return tipo_imagen;
    }

    public void setTipo_imagen(clase_imagen tipo_imagen) {
        this.tipo_imagen = tipo_imagen;
    }

    public static int getPosision() {
        return posision;
    }

}

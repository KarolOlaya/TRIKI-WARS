package jugabilidad;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.RoundRectangle2D;// clase para hacer un restangulo redondeado fondo
import javax.swing.JPanel;

public class redondeado extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create(); //que las demas cosas se muestren encima
        // darle tamaño al redondeado y el -1 es para que no se salga de la ventana
        RoundRectangle2D.Double redonda = new RoundRectangle2D.Double(0, 0, this.getWidth() - 1, this.getHeight() - 1, 50, 50);
        g2.setColor(this.getBackground());// para que tenga el mismo color de fondo
        g2.fill(redonda);// rellenar
        g2.draw(redonda);// dibujar margen
        g2.dispose(); // para q se haga una sola vez
    }
}

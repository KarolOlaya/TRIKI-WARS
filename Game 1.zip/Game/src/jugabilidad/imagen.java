package jugabilidad;

import java.awt.Graphics;//permite modificar las imagenes
import java.awt.Graphics2D;//permite modificar mas las imagenes
import java.net.URL; // especificar mas la ruta de la imagen
import javax.swing.ImageIcon; // hace q se vea la imagen
import javax.swing.JLabel;

//para poner las imagenes utilizadas
public class imagen extends JLabel {

    private String ruta = "";

    @Override
    protected void paintComponent(Graphics gg) {
        Graphics2D g = (Graphics2D) gg;// almacenamos los graficos gg en los graficos 2d g para que haya mas opciones de personalizacion             
        URL rutaAbsolute = getClass().getResource(ruta); /* los metodos getClass y getResource guardan lo que esta en ruta en rutaAbsolute */
        if (rutaAbsolute != null) {//si la rutaAbsolute es diferente de algo vacio se crea una imgen de la misma y se muestra
            ImageIcon imagen = new ImageIcon(rutaAbsolute);// crea una imagen segun la ruta que se le asigne
            g.drawImage(imagen.getImage(), 0, 0, this.getWidth(), this.getHeight(), null);// adapta la imagen en el cuadro
        }
        g.dispose();// cerrar el paint component para q la imagen se dibuje una sola vez
    }

    public void setRuta(String ruta) {
        this.ruta = ruta; 
    }
}

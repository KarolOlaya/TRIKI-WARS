package jugabilidad;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JPanel;

// crear los cuadritos negros
public class fondo_recuadro extends JPanel{
    
    private int ancho;
    private int altura;
    private Color color;
    
    public fondo_recuadro(int ancho, int altura, Color color){
        this.ancho = ancho;
        this.altura = altura;
        this.color = color;
        setSize(ancho, altura);
        setBackground(color);       
    }

    @Override
    protected void paintComponent(Graphics gg) {
        super.paintComponent(gg);
        Graphics2D g5 = (Graphics2D)gg;
        RoundRectangle2D.Double redonda = new RoundRectangle2D.Double(0,0,this.getWidth()-1,this.getHeight()-1,50,50);
       
        g5.setColor(this.getBackground());
        g5.fill(redonda);//rellenar
        g5.draw(redonda);
        g5.dispose();   
    }

    // setters cambian el valor de ancho y altura

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }
    
}
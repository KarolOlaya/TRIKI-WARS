package jugabilidad;


public enum clase_imagen {
    
// se crean los objeto usando una clase numerada, ya q todo objeto en una clase enum es estatico
equis,circulo,triangulo,empate,linea1,linea2,linea3,linea4,linea5,linea6,linea7,linea8
}

package jugabilidad;

import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

// dibujar lineas de triqui
public class dibujar_lineas extends JPanel{
    
    private int ancho;
    private int altura;
    private clase_imagen dibuja_linea;// dice si es la linea1 o 2, o 3 ...
    
    public dibujar_lineas(int ancho, int altura){
        this.ancho = ancho;
        this.altura = altura;
        setSize(ancho, altura);     
    }

    @Override
    protected void paintComponent(Graphics gg) {
        Graphics2D g4 = (Graphics2D)gg;
        
        ImageIcon imagen = new ImageIcon();// crea una imagen segun la ruta que se le asigne
        
        if(dibuja_linea==clase_imagen.linea1){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA1));
        }
        else if(dibuja_linea==clase_imagen.linea2){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA2));
        }
        else if(dibuja_linea==clase_imagen.linea3){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA3));
        }
        else if(dibuja_linea==clase_imagen.linea4){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA4));
        }
        else if(dibuja_linea==clase_imagen.linea5){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA5));
        }
        else if(dibuja_linea==clase_imagen.linea6){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA6));
        }
        else if(dibuja_linea==clase_imagen.linea7){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA7));
        }
        else if(dibuja_linea==clase_imagen.linea8){
            imagen=new ImageIcon(getClass().getResource(ruta.LINEA8));
        }
        
        // los if dan la ruta y el draw dibuja
        g4.drawImage(imagen.getImage(),0,0,this.getWidth(),this.getHeight(),null);
        // esta en 00 porq se dibuja en el centro del tablero
    }

    public void setAncho(int ancho) {
        this.ancho = ancho;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public clase_imagen getDibuja_linea() {
        return dibuja_linea;
    }

    public void setDibuja_linea(clase_imagen dibuja_imagen) {
        this.dibuja_linea = dibuja_imagen;
    }        
}